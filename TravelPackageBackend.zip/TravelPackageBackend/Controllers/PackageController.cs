using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using TravelPackageBackend.Contracts;
using TravelPackageBackend.Services;

namespace TravelPackageBackend.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PackageController : ControllerBase
    {

        private readonly ILogger<PackageController> _logger;
        private readonly IPackageService _packageService;

        public PackageController(ILogger<PackageController> logger, IPackageService packageService)
        {
            _logger = logger;
            _packageService = packageService;
        }

        [HttpGet]
        [Route("GetPackages")]
        public async Task<IEnumerable<Package>> GetPackages()
        {
            return await _packageService.GetPackages();
        }

        [HttpGet]
        [Route("{id}")]
        public async Task<PackageDetails> GetPackageById([FromRoute] string id)
        {
            return await _packageService.GetPackageDetails(id);
        }
    }
}
