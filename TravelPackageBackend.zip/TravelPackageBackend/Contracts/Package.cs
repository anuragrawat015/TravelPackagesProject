﻿namespace TravelPackageBackend.Contracts
{
    public class Package
    {
        public string? Id { get; set; } 
        public string? PackageName { get; set; }
        public bool IncludesFlights { get; set; }
        public int NumberOfHotels { get; set; }
        public string? HotelType { get; set; }
        public int NumberOfActivities { get; set; }
        public List<string> Activities { get; set; } = new List<string>();
        public int PricingPerPerson { get; set; }
        public int NumberOfNights { get; set; }
        public int NumberOfDays { get; set; }
        public string? Image { get; set; }
    }



}
