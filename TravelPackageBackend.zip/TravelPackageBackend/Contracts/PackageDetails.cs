﻿namespace TravelPackageBackend.Contracts
{
    public class PackageDetails
    {
        public string? Id { get; set; }
        public Dictionary<string, Day> Details { get; set; } = new Dictionary<string, Day>();
    }

    public class Day
    {
        public List<Flight> FlightDetails { get; set; }  = new List<Flight>();
        public List<Hotel> HotelDetails { get; set; } = new List<Hotel>();
        public List<Activity> ActivityDetails { get; set; } = new List<Activity>();
        public List<Car> CarDetails { get; set; } = new List<Car>();
    }
}
