﻿namespace TravelPackageBackend.Contracts
{
    public class Hotel
    {
        public string? HotelName { get; set; }
        public string? Address { get; set; }
        public DateTime CheckInTime { get; set; }
        public DateTime CheckOutTime { get; set; }
        public string? PricePerNight { get; set; }
        public int Rating { get; set; }
        public List<string> Amenities { get; set; } = new List<string>();
        public Dictionary<string,string> DistanceToAttractions { get; set; } = new Dictionary<string,string>();
        public string? ImageLink { get; set; }
    }
}
