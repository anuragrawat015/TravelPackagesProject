﻿namespace TravelPackageBackend.Contracts
{
    public class Activity
    {
        public string? ActivityName { get; set; }
        public string? Location { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public int Duration { get; set; }
        public string? Price { get; set; }
        public string? Description { get; set; }
        public double Rating { get; set; }
        public string? ImageLink { get; set; }
    }
}
