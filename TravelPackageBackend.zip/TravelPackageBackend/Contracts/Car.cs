﻿namespace TravelPackageBackend.Contracts
{
    public class Car
    {
        public string? CarModel { get; set; }
        public string? RentalAgency { get; set; }
        public DateTime PickUpTime { get; set; }
        public DateTime DropOffTime { get; set; }
        public string? PricePerDay { get; set; }
        public string? FuelPolicy { get; set; }
        public string? Transmission { get; set; }
        public List<string>? Features { get; set; }
        public string? PickUpLocation { get; set; }
        public string? DropOffLocation { get; set; }
        public string? ImageLink { get; set; }
    }
}
