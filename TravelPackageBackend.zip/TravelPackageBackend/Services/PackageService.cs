﻿using System.Text.Json;
using TravelPackageBackend.Contracts;

namespace TravelPackageBackend.Services
{
    public class PackageService : IPackageService
    {
        private readonly JsonSerializerOptions _options = new()
        {
            PropertyNameCaseInsensitive = true
        };
        public PackageService()
        {

        }


        public async Task<List<Package>> GetPackages()
        {
            var json = File.ReadAllText(Directory.GetCurrentDirectory() + "/Mocks/PackageListing.json");
            List<Package>? packages = JsonSerializer.Deserialize<List<Package>>(json, _options);
            return packages;
        }

        public async Task<PackageDetails> GetPackageDetails(string packageId)
        {
            var json = File.ReadAllText(Directory.GetCurrentDirectory() + "/Mocks/PackageListing.json");
            List<Package>? packages = JsonSerializer.Deserialize<List<Package>>(json, _options);
            var packageTemplate = packages.SingleOrDefault(c => c.Id == packageId);
            if (packageTemplate == null) { throw new Exception("Package not found"); }
            var packageDetails = new PackageDetails { Id = packageTemplate.Id };

            var flightDetails = GetFlightDetails();
            var hotelDetails = GetHotelDetails();   
            var activityDetails = GetActivitiesDetails();
            var carDetails = GetCarDetails();

            int numberOfTripPartition = packageTemplate.NumberOfDays / 3;
            int count = -2;
            var day = new Day();
            var flight = flightDetails.OrderBy(f => f.Price).FirstOrDefault();
            day.FlightDetails.Add(flight);

            for (int i = 0; i < numberOfTripPartition; i++)
            {
                count += 3;
                
                var closestHotel = hotelDetails
               .OrderBy(h => Math.Abs((h.CheckInTime - flight.ArrivalTime).TotalMinutes))
               .FirstOrDefault();

                hotelDetails.Remove(closestHotel);   // remove previous added hotel

                day.HotelDetails.Add(closestHotel);


                packageDetails.Details.Add($"Day{count}", day);
                day = new Day();
                var dateOneDayAfterCheckIn = closestHotel.CheckInTime.AddDays(1);

                var relevantActivities = activityDetails
                    .Where(a => a.StartTime.Date == dateOneDayAfterCheckIn.Date)
                    .ToList();

                var morningActivities = relevantActivities
               .Where(a => a.StartTime.Hour < 11)
               .OrderBy(a => a.StartTime)
               .Take(1)
               .FirstOrDefault();

                //activityDetails.Remove(morningActivities);

                day.ActivityDetails.Add(morningActivities);

                // lunch break 

                var afternoonActivities = relevantActivities
                    .Where(a => a.StartTime.Hour >= 14)
                    .OrderBy(a => a.StartTime)
                    .Take(1)
                    .FirstOrDefault();

               // activityDetails.Remove(afternoonActivities);

                //dinner
                day.ActivityDetails.Add(afternoonActivities);
                packageDetails.Details.Add($"Day{count + 1}", day);

                day = new Day();
                var dateTwoDayAfterCheckIn = closestHotel.CheckInTime.AddDays(2);

                var relevantActivities1 = activityDetails
                    .Where(a => a.StartTime.Date == dateTwoDayAfterCheckIn.Date)
                    .ToList();

                var morningActivities1 = relevantActivities1
               .Where(a => a.StartTime.Hour < 11)
               .OrderBy(a => a.StartTime)
               .Take(1)
               .FirstOrDefault();

              //  activityDetails.Remove(morningActivities1);
                day.ActivityDetails.Add(morningActivities1);

                // lunch break 

                var afternoonActivities1 = relevantActivities1
                    .Where(a => a.StartTime.Hour >= 14)
                    .OrderBy(a => a.StartTime)
                    .Take(1)
                    .FirstOrDefault();

                day.ActivityDetails.Add(afternoonActivities1);

               // activityDetails.Remove(morningActivities1);
                //dinner

                packageDetails.Details.Add($"Day{count + 2}", day);

                day = new Day();

            }

            var departureFlight = flightDetails
              .Where(a => a.DepartureTime.Date.Day == 11)
              .Take(1)
              .FirstOrDefault();
            var departureDay = new Day();
            departureDay.FlightDetails.Add(departureFlight);
            packageDetails.Details.Add($"Day{count + 3}", departureDay);
            return packageDetails;

        }

        private List<Flight> GetFlightDetails()
        {
            var json = File.ReadAllText(Directory.GetCurrentDirectory() + "/Mocks/FlightList.json");
            List<Flight>? flights = JsonSerializer.Deserialize<List<Flight>>(json, _options);
            return flights;
        }

        private List<Hotel> GetHotelDetails()
        {
            var json = File.ReadAllText(Directory.GetCurrentDirectory() + "/Mocks/Hotel.json");
            List<Hotel>? hotels = JsonSerializer.Deserialize<List<Hotel>>(json, _options);
            return hotels;
        }

        private List<Activity> GetActivitiesDetails()
        {
            var json = File.ReadAllText(Directory.GetCurrentDirectory() + "/Mocks/Activity.json");
            List<Activity>? activities = JsonSerializer.Deserialize<List<Activity>>(json, _options);
            return activities;
        }

        private List<Car> GetCarDetails()
        {
            var json = File.ReadAllText(Directory.GetCurrentDirectory() + "/Mocks/Car9Aug.json");
            List<Car>? cars = JsonSerializer.Deserialize<List<Car>>(json, _options);
            return cars;
        }


    }
}
