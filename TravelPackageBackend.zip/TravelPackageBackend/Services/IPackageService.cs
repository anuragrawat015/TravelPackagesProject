﻿using TravelPackageBackend.Contracts;

namespace TravelPackageBackend.Services
{
    public interface IPackageService
    {
        public Task<List<Package>>? GetPackages();
        public Task<PackageDetails> GetPackageDetails(string packageId);
    }
}
